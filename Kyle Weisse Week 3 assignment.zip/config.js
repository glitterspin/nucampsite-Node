module.exports = {
    'secretKey': '12345-12345',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite'
}